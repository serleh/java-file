/*--
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package filereader;

import java.io.*;
import java.util.Scanner;

/**
 *  
 * @author HP
 */
public class FileReade {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException {

        // BufferedReader object for file1.txt
        BufferedReader br1 = new BufferedReader(new FileReader("file1.txt"));

        // BufferedReader object for file2.txt
        BufferedReader br2 = new BufferedReader(new FileReader("file2.txt"));
        
       
             

           //printWriter object for file3.txt
        PrintWriter pw = new PrintWriter("file3.txt");

          //printWriter object for file4.txt
        PrintWriter pw1 = new PrintWriter("file4.txt");
        

           // declaring String for br1
        String line1 = br1.readLine();
        
           //declaring String for br2
        String line2 = br2.readLine();

          // Printing the content of file1.txt
        System.out.println("(1) The contents of file1 when displayed =  " );
        System.out.println( "\t\t"+line1);
        System.out.println();
        
          // Printing the content of file2.txt
        System.out.println("(2)The contents of file2 when displayed =   ");
        System.out.println( "\t\t"+line2);

           //loop to copy lines of file1.txt to file3.txt
        while (line1 != null) {
            pw.print(line1);

            line1 = br1.readLine();

        }
        //loop to copy lines of file2.txt to file3.txt
        while (line2 != null) {
            pw.print(line2);

            line2 = br2.readLine();

        }

        // closing resources
        pw.close();

        // bufferedReader for file3.txt
        BufferedReader br3 = new BufferedReader(new FileReader("file3.txt"));

        // Scanner object for br3
        Scanner sc = new Scanner(br3);

        //  File for file3.txt
        File file = new File("file3.txt");

        System.out.println();

        // printing the concatenated value of file1.txt and file2.txt to file3.txt
        System.out.println("(3) When We concatenate the contents of text1 and text2 = " );
        System.out.println( "\t\t"+ sc.nextLine());

        System.out.println();

        // printing the number of characters in file3.txt
        System.out.println("(4)Total number of characters present in file3 = ");
        System.out.println( "\t\t"+ file.length());
        
        
        System.out.println();

        // printing the Square of the numbers of characters 
        System.out.println("(5) The Square of the numbers of characters in file3 = ");
        System.out.println("\t\t"+file.length()*file.length());
        
         //declaring  variable to square the number of characters
         long sq=  file.length()*file.length();
         
         //printing the square of characters to file4.txt
         if(file !=null) {        
            pw1.print(sq);
            pw1.close();
        }
         
    }

}
